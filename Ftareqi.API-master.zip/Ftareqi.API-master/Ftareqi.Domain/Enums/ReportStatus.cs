﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ftareqi.Domain.Enums
{
	public enum ReportStatus
	{
		Pending,
		Resolved,
		Rejected
	}
}
