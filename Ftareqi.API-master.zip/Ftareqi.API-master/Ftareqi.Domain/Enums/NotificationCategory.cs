﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ftareqi.Domain.Enums
{
	public enum NotificationCategory
	{
		Ride = 1,
		Wallet = 2,
		DriverRegistration=3,
		System = 4,
		Review = 5,
		Report=6,
		Ban=7
	}
}
