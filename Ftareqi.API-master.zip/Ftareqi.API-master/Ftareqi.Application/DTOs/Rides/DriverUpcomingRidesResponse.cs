using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ftareqi.Domain.Enums;

namespace Ftareqi.Application.DTOs.Rides
{
	public class DriverUpcomingRidesResponse
	{
		public int RideId { get; set; }
		public double StartLatitude { get; set; }
		public double StartLongitude { get; set; }
		public string StartAddress { get; set; } = string.Empty;
		public double EndLatitude { get; set; }
		public double EndLongitude { get; set; }
		public string EndAddress { get; set; } = string.Empty;
		public int TotalSeats { get; set; }
		public int AvailableSeats { get; set; }
		public decimal PricePerSeat { get; set; }
		public RideStatus Status { get; set; }
		public int WaitingTimeMinutes { get; set; }
		public DateTime DepartureTime { get; set; }
		public bool MusicAllowed { get; set; }
		public bool NoSmoking { get; set; }
		public bool PetsWelcomed { get; set; }
		public bool OpenToConversation { get; set; }
	}
}
