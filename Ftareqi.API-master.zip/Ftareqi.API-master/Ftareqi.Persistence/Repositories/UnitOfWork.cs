﻿using Ftareqi.Application.Interfaces.Repositories;
using Ftareqi.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ftareqi.Persistence.Repositories
{
	public class UnitOfWork : IUnitOfWork
	{
		private readonly ApplicationDbContext _applicationDbContext;
		public IBaseRepository<User> Users {  get; private set; }
		public IBaseRepository<RefreshToken> RefreshTokens {  get; private set; }
		public IBaseRepository<OTP> OTPs {  get; private set; }
		public IDriverProfileRepository DriverProfiles {  get; private set; }
		public IBaseRepository<Image> Images {  get; private set; }
		public IBaseRepository<Car> Cars {  get; private set; }
		public IBaseRepository <UserWallet> UserWallets { get; private set;}
		public IBaseRepository <WalletTransaction> WalletTransactions { get; private set; }
		public IBaseRepository <PaymentTransaction> PaymentTransactions { get; private set; }
		public IBaseRepository <Notification> Notifications { get; private set; }
		public IBaseRepository <FcmToken> FcmTokens { get; private set; }
		public IBaseRepository <RidePreferences> RidePreferences { get; private set; }
		public IRideRepository Rides { get; private set; }
		public IRideBookingRepository RideBookings { get; private set; }
		public IBaseRepository <Review> Reviews { get; private set; }
		public IBaseRepository <Report> Reports { get; private set; }
		public IBaseRepository <Ban> Bans { get; private set; }

		public UnitOfWork(ApplicationDbContext applicationDbContext)
		{
			_applicationDbContext = applicationDbContext;
			Users = new BaseRepository<User>(_applicationDbContext);
			RefreshTokens = new BaseRepository<RefreshToken>(_applicationDbContext);
			OTPs = new BaseRepository<OTP>(_applicationDbContext);
			DriverProfiles= new DriverProfileRepository(_applicationDbContext);
			Images= new BaseRepository<Image>(_applicationDbContext);
			Cars= new BaseRepository<Car>(_applicationDbContext);
			UserWallets = new BaseRepository<UserWallet>(_applicationDbContext);
			WalletTransactions = new BaseRepository<WalletTransaction> (_applicationDbContext);
			PaymentTransactions=new BaseRepository<PaymentTransaction> (_applicationDbContext);
			Notifications=new BaseRepository<Notification> (_applicationDbContext);
			FcmTokens= new BaseRepository<FcmToken> (_applicationDbContext);
			RidePreferences = new BaseRepository<RidePreferences> (_applicationDbContext);
			Rides = new RideRepository(_applicationDbContext);
			RideBookings = new RideBookingRepository(_applicationDbContext);
			Reviews = new BaseRepository<Review> (_applicationDbContext);
			Reports = new BaseRepository<Report> (_applicationDbContext);
			Bans = new BaseRepository<Ban> (_applicationDbContext);

		}
		public ValueTask DisposeAsync()
		{
			return _applicationDbContext.DisposeAsync();
		}

		public Task<int> SaveChangesAsync()
		{
			return _applicationDbContext.SaveChangesAsync();
		}

		public async Task<IDbContextTransaction> BeginTransactionAsync()
		{
			return await _applicationDbContext.Database.BeginTransactionAsync();
		}
	}
}
